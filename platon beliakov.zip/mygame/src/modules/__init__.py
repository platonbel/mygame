from . import mysprites
from . import mymodules

NAME = "modules"